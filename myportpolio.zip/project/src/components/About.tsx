import React from 'react';
import { Award, Users, Lightbulb, Target } from 'lucide-react';
import { motion } from 'framer-motion';

const About = () => {
  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    whileInView: { opacity: 1, y: 0 },
    transition: { duration: 0.6 },
    viewport: { once: true }
  };

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          {...fadeInUp}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-dark-800 mb-6">
            About KAZAUREE DIGITAL HUB
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Crafting digital excellence with passion, innovation, and expertise
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative perspective-1000">
              <div className="absolute -inset-4 bg-gradient-to-r from-orange-400 to-orange-600 rounded-2xl blur opacity-20"></div>
              <motion.div 
                className="relative bg-white rounded-2xl p-8 shadow-xl border border-gray-100 transform-style-3d"
                whileHover={{ rotateY: 5, scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="text-center">
                  <motion.div 
                    className="w-32 h-32 mx-auto mb-6 rounded-full overflow-hidden shadow-lg relative"
                    whileHover={{ scale: 1.1 }}
                  >
                    <img 
                      src="/PROFILE.jpg" 
                      alt="Auwal Saleh - Founder" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-orange-500/20 to-transparent"></div>
                  </motion.div>
                  <h3 className="text-2xl font-bold text-dark-800 mb-2">Auwal Saleh</h3>
                  <p className="text-orange-600 font-semibold mb-4">Founder & Creative Developer</p>
                  <div className="h-1 w-24 bg-gradient-to-r from-orange-400 to-orange-600 mx-auto mb-6"></div>
                  <p className="text-gray-600 leading-relaxed">
                    "With over 5 years of experience in digital design and development, I founded KAZAUREE DIGITAL HUB to help businesses transform their vision into powerful digital experiences. Our team is passionate about creating solutions that not only look amazing but deliver real results."
                  </p>
                </div>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div>
              <h3 className="text-3xl font-bold text-dark-800 mb-6">Our Mission</h3>
              <p className="text-lg text-gray-600 mb-6">
                We craft stunning visuals and powerful websites to elevate brands worldwide. Our mission is to bridge the gap between creative vision and technical excellence, delivering solutions that drive business growth.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <motion.div
                whileHover={{ scale: 1.05, rotateY: 5 }}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 transform-style-3d"
              >
                <Award className="w-8 h-8 text-orange-500 mb-3" />
                <h4 className="font-semibold text-dark-800 mb-2">Quality First</h4>
                <p className="text-gray-600 text-sm">Every project meets the highest standards of excellence</p>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05, rotateY: 5 }}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 transform-style-3d"
              >
                <Users className="w-8 h-8 text-orange-600 mb-3" />
                <h4 className="font-semibold text-dark-800 mb-2">Client-Focused</h4>
                <p className="text-gray-600 text-sm">Your success is our primary goal and measure of achievement</p>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05, rotateY: 5 }}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 transform-style-3d"
              >
                <Lightbulb className="w-8 h-8 text-orange-500 mb-3" />
                <h4 className="font-semibold text-dark-800 mb-2">Innovation</h4>
                <p className="text-gray-600 text-sm">Cutting-edge solutions using the latest technologies</p>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05, rotateY: 5 }}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 transform-style-3d"
              >
                <Target className="w-8 h-8 text-orange-600 mb-3" />
                <h4 className="font-semibold text-dark-800 mb-2">Results-Driven</h4>
                <p className="text-gray-600 text-sm">Measurable outcomes that exceed expectations</p>
              </motion.div>
            </div>
          </motion.div>
        </div>

        <motion.div
          {...fadeInUp}
          className="bg-gradient-to-r from-dark-800 to-dark-900 rounded-3xl p-12 text-center text-white relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-orange-600/10"></div>
          <div className="relative z-10">
            <h3 className="text-3xl font-bold mb-6">Why Choose KAZAUREE?</h3>
            <div className="grid md:grid-cols-3 gap-8">
              <motion.div whileHover={{ scale: 1.1 }}>
                <div className="text-4xl font-bold text-orange-400 mb-2">5+</div>
                <div className="text-lg">Years Experience</div>
              </motion.div>
              <motion.div whileHover={{ scale: 1.1 }}>
                <div className="text-4xl font-bold text-orange-400 mb-2">50+</div>
                <div className="text-lg">Happy Clients</div>
              </motion.div>
              <motion.div whileHover={{ scale: 1.1 }}>
                <div className="text-4xl font-bold text-orange-400 mb-2">100%</div>
                <div className="text-lg">Project Success Rate</div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;