import React, { useState } from 'react';
import { Briefcase, Users, TrendingUp, Award, MapPin, Clock, DollarSign, Send, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const Careers = () => {
  const [selectedJob, setSelectedJob] = useState<number | null>(null);
  const [applicationData, setApplicationData] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    experience: '',
    portfolio: '',
    coverLetter: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const jobOpenings = [
    {
      id: 1,
      title: 'Senior Graphic Designer',
      department: 'Design',
      location: 'Damaturu, Yobe State',
      type: 'Full-time',
      salary: '₦150,000 - ₦250,000',
      description: 'We are looking for a creative and experienced graphic designer to join our team and help create stunning visual content for our clients.',
      requirements: [
        '3+ years of graphic design experience',
        'Proficiency in Adobe Creative Suite',
        'Strong portfolio showcasing diverse design work',
        'Experience with brand identity and logo design',
        'Knowledge of print and digital design principles'
      ],
      responsibilities: [
        'Create visual concepts and designs for various projects',
        'Collaborate with clients to understand their design needs',
        'Develop brand identities and marketing materials',
        'Ensure all designs meet quality standards and deadlines',
        'Stay updated with design trends and best practices'
      ]
    },
    {
      id: 2,
      title: 'Frontend Developer',
      department: 'Development',
      location: 'Damaturu, Yobe State',
      type: 'Full-time',
      salary: '₦200,000 - ₦350,000',
      description: 'Join our development team to build responsive, user-friendly websites and web applications using modern technologies.',
      requirements: [
        '2+ years of frontend development experience',
        'Proficiency in HTML, CSS, JavaScript',
        'Experience with React, Vue.js, or Angular',
        'Knowledge of responsive design principles',
        'Familiarity with version control (Git)'
      ],
      responsibilities: [
        'Develop responsive and interactive web interfaces',
        'Collaborate with designers to implement UI/UX designs',
        'Optimize websites for performance and SEO',
        'Write clean, maintainable code',
        'Test and debug web applications'
      ]
    },
    {
      id: 3,
      title: 'Digital Marketing Specialist',
      department: 'Marketing',
      location: 'Remote/Hybrid',
      type: 'Full-time',
      salary: '₦120,000 - ₦200,000',
      description: 'Help our clients grow their online presence through strategic digital marketing campaigns and social media management.',
      requirements: [
        '2+ years of digital marketing experience',
        'Knowledge of SEO, SEM, and social media marketing',
        'Experience with Google Analytics and Ads',
        'Strong analytical and communication skills',
        'Familiarity with content management systems'
      ],
      responsibilities: [
        'Develop and execute digital marketing strategies',
        'Manage social media accounts and campaigns',
        'Create engaging content for various platforms',
        'Analyze campaign performance and optimize results',
        'Stay updated with digital marketing trends'
      ]
    },
    {
      id: 4,
      title: 'UI/UX Designer',
      department: 'Design',
      location: 'Damaturu, Yobe State',
      type: 'Full-time',
      salary: '₦180,000 - ₦280,000',
      description: 'Design intuitive and engaging user experiences for web and mobile applications, focusing on user-centered design principles.',
      requirements: [
        '2+ years of UI/UX design experience',
        'Proficiency in Figma, Sketch, or Adobe XD',
        'Strong understanding of user-centered design',
        'Experience with wireframing and prototyping',
        'Knowledge of usability testing principles'
      ],
      responsibilities: [
        'Create user-centered designs for web and mobile apps',
        'Conduct user research and usability testing',
        'Develop wireframes, prototypes, and design systems',
        'Collaborate with developers to ensure design implementation',
        'Present design concepts to clients and stakeholders'
      ]
    }
  ];

  const benefits = [
    {
      icon: TrendingUp,
      title: 'Career Growth',
      description: 'Continuous learning opportunities and clear career progression paths'
    },
    {
      icon: Users,
      title: 'Collaborative Team',
      description: 'Work with talented professionals in a supportive environment'
    },
    {
      icon: Award,
      title: 'Recognition',
      description: 'Performance-based bonuses and recognition programs'
    },
    {
      icon: Briefcase,
      title: 'Work-Life Balance',
      description: 'Flexible working hours and remote work options'
    }
  ];

  const handleApplicationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
    setApplicationData({
      name: '',
      email: '',
      phone: '',
      position: '',
      experience: '',
      portfolio: '',
      coverLetter: ''
    });
    setSelectedJob(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setApplicationData({
      ...applicationData,
      [e.target.name]: e.target.value
    });
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    whileInView: { opacity: 1, y: 0 },
    transition: { duration: 0.6 },
    viewport: { once: true }
  };

  return (
    <section id="careers" className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          {...fadeInUp}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-dark-800 mb-6">
            Join Our Team
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Be part of a dynamic team that's shaping the future of digital creativity. We're always looking for talented individuals to join our mission.
          </p>
        </motion.div>

        {/* Company Culture */}
        <motion.div
          {...fadeInUp}
          className="mb-16 bg-gradient-to-r from-orange-500 to-orange-600 rounded-3xl p-12 text-white relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-600/20 to-orange-700/20"></div>
          <div className="relative z-10 text-center">
            <h3 className="text-3xl font-bold mb-6">Why Work With Us?</h3>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              At KAZAUREE DIGITAL HUB, we believe in fostering creativity, innovation, and professional growth. Join us in creating digital masterpieces that make a difference.
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className="bg-white/20 backdrop-blur-sm p-4 rounded-xl mb-4 inline-block">
                    <benefit.icon className="w-8 h-8" />
                  </div>
                  <h4 className="font-semibold mb-2">{benefit.title}</h4>
                  <p className="text-sm opacity-90">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Job Openings */}
        <motion.div
          {...fadeInUp}
          className="mb-16"
        >
          <h3 className="text-3xl font-bold text-dark-800 mb-8 text-center">Current Openings</h3>
          <div className="grid gap-6">
            {jobOpenings.map((job, index) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all"
              >
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
                  <div>
                    <h4 className="text-2xl font-bold text-dark-800 mb-2">{job.title}</h4>
                    <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Briefcase className="w-4 h-4 mr-2 text-orange-500" />
                        {job.department}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2 text-orange-500" />
                        {job.location}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-orange-500" />
                        {job.type}
                      </div>
                      <div className="flex items-center">
                        <DollarSign className="w-4 h-4 mr-2 text-orange-500" />
                        {job.salary}
                      </div>
                    </div>
                  </div>
                  <motion.button
                    onClick={() => setSelectedJob(selectedJob === job.id ? null : job.id)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg transition-all mt-4 lg:mt-0"
                  >
                    {selectedJob === job.id ? 'Close Details' : 'View Details'}
                  </motion.button>
                </div>

                <p className="text-gray-600 mb-4">{job.description}</p>

                {selectedJob === job.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-gray-200 pt-6"
                  >
                    <div className="grid md:grid-cols-2 gap-8 mb-8">
                      <div>
                        <h5 className="font-semibold text-dark-800 mb-4">Requirements:</h5>
                        <ul className="space-y-2">
                          {job.requirements.map((req, reqIndex) => (
                            <li key={reqIndex} className="flex items-start">
                              <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-600 text-sm">{req}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="font-semibold text-dark-800 mb-4">Responsibilities:</h5>
                        <ul className="space-y-2">
                          {job.responsibilities.map((resp, respIndex) => (
                            <li key={respIndex} className="flex items-start">
                              <CheckCircle className="w-4 h-4 text-orange-500 mr-2 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-600 text-sm">{resp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Application Form */}
                    <div className="bg-gray-50 rounded-xl p-6">
                      <h5 className="font-semibold text-dark-800 mb-4">Apply for this position</h5>
                      
                      {isSubmitted && (
                        <motion.div
                          initial={{ opacity: 0, y: -20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-6 flex items-center"
                        >
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Thank you! Your application has been submitted successfully.
                        </motion.div>
                      )}

                      <form onSubmit={handleApplicationSubmit} className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <input
                            type="text"
                            name="name"
                            value={applicationData.name}
                            onChange={handleInputChange}
                            placeholder="Full Name *"
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          />
                          <input
                            type="email"
                            name="email"
                            value={applicationData.email}
                            onChange={handleInputChange}
                            placeholder="Email Address *"
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                          <input
                            type="tel"
                            name="phone"
                            value={applicationData.phone}
                            onChange={handleInputChange}
                            placeholder="Phone Number *"
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          />
                          <select
                            name="experience"
                            value={applicationData.experience}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          >
                            <option value="">Years of Experience *</option>
                            <option value="0-1">0-1 years</option>
                            <option value="2-3">2-3 years</option>
                            <option value="4-5">4-5 years</option>
                            <option value="5+">5+ years</option>
                          </select>
                        </div>
                        <input
                          type="url"
                          name="portfolio"
                          value={applicationData.portfolio}
                          onChange={handleInputChange}
                          placeholder="Portfolio/LinkedIn URL"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        />
                        <textarea
                          name="coverLetter"
                          value={applicationData.coverLetter}
                          onChange={handleInputChange}
                          placeholder="Cover Letter / Why do you want to join our team? *"
                          required
                          rows={4}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                        ></textarea>
                        <motion.button
                          type="submit"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-4 px-6 rounded-xl font-semibold hover:shadow-xl transition-all flex items-center justify-center"
                        >
                          <span>Submit Application</span>
                          <Send className="ml-2 w-5 h-5" />
                        </motion.button>
                      </form>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          {...fadeInUp}
          className="text-center bg-gradient-to-r from-dark-800 to-dark-900 rounded-3xl p-12 text-white relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-orange-600/10"></div>
          <div className="relative z-10">
            <h3 className="text-3xl font-bold mb-6">Don't See Your Role?</h3>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              We're always looking for talented individuals. Send us your resume and let us know how you can contribute to our team.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl transition-all"
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Send Your Resume
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Careers;