import React from 'react';
import { Facebook, Instagram, Mail, Phone, MapPin, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gradient-to-br from-dark-900 via-dark-800 to-dark-950 text-white relative overflow-hidden">
      {/* 3D Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-orange-400/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '-2s' }}></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <div className="flex items-center space-x-3 mb-6">
              <motion.div 
                className="relative"
                whileHover={{ scale: 1.1, rotateZ: 5 }}
              >
                <img 
                  src="/LOGO.JPG" 
                  alt="KAZAUREE DIGITAL HUB" 
                  className="h-12 w-auto object-contain"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-transparent rounded-lg blur-sm"></div>
              </motion.div>
              <div>
                <h3 className="text-2xl font-bold">KAZAUREE DIGITAL HUB</h3>
                <p className="text-gray-300">Creative Digital Solutions</p>
              </div>
            </div>
            
            <p className="text-gray-300 mb-6 leading-relaxed max-w-md">
              Transforming ideas into digital masterpieces. We craft stunning visuals and powerful websites to elevate brands worldwide.
            </p>

            <div className="space-y-3">
              <motion.div 
                className="flex items-center text-gray-300"
                whileHover={{ x: 5 }}
              >
                <MapPin className="w-5 h-5 mr-3 text-orange-400" />
                <span>Abasha Ward, Damaturu, Yobe State, Nigeria</span>
              </motion.div>
              <motion.div 
                className="flex items-center text-gray-300"
                whileHover={{ x: 5 }}
              >
                <Phone className="w-5 h-5 mr-3 text-orange-500" />
                <span>+2348103757754</span>
              </motion.div>
              <motion.div 
                className="flex items-center text-gray-300"
                whileHover={{ x: 5 }}
              >
                <Mail className="w-5 h-5 mr-3 text-orange-400" />
                <span>info@kazaureedigitalhub.com</span>
              </motion.div>
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="text-xl font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { name: 'About Us', id: 'about' },
                { name: 'Services', id: 'services' },
                { name: 'Portfolio', id: 'portfolio' },
                { name: 'Careers', id: 'careers' },
                { name: 'Contact', id: 'contact' }
              ].map((link) => (
                <li key={link.name}>
                  <motion.button
                    onClick={() => scrollToSection(link.id)}
                    className="text-gray-300 hover:text-orange-400 transition-colors"
                    whileHover={{ x: 5 }}
                  >
                    {link.name}
                  </motion.button>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="text-xl font-bold mb-6">Our Services</h4>
            <ul className="space-y-3">
              {[
                'Graphic Design',
                'Web Development',
                'UI/UX Design',
                'Digital Marketing',
                'Brand Strategy',
                'Creative Consulting'
              ].map((service) => (
                <li key={service}>
                  <motion.span 
                    className="text-gray-300 hover:text-orange-400 transition-colors cursor-pointer"
                    whileHover={{ x: 5 }}
                  >
                    {service}
                  </motion.span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        {/* Social Media & Bottom Section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="border-t border-white/10 mt-12 pt-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-6 mb-4 md:mb-0">
              <span className="text-gray-300">Follow us:</span>
              <div className="flex space-x-4">
                <motion.a
                  href="#"
                  whileHover={{ scale: 1.1, rotateZ: 5 }}
                  className="bg-blue-600 p-3 rounded-full hover:bg-blue-700 transition-colors shadow-lg"
                >
                  <Facebook className="w-5 h-5" />
                </motion.a>
                <motion.a
                  href="#"
                  whileHover={{ scale: 1.1, rotateZ: 5 }}
                  className="bg-gradient-to-r from-pink-500 to-purple-600 p-3 rounded-full hover:shadow-lg transition-all"
                >
                  <Instagram className="w-5 h-5" />
                </motion.a>
              </div>
            </div>

            <div className="text-center md:text-right">
              <p className="text-gray-300 flex items-center justify-center md:justify-end">
                Made with <Heart className="w-4 h-4 mx-2 text-red-400" /> by KAZAUREE DIGITAL HUB
              </p>
              <p className="text-gray-400 text-sm mt-1">
                © 2024 KAZAUREE DIGITAL HUB. All Rights Reserved.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12 bg-gradient-to-r from-white/5 to-white/10 rounded-2xl p-8 border border-white/10 backdrop-blur-sm"
        >
          <h3 className="text-2xl font-bold mb-4">Ready to Start Your Project?</h3>
          <p className="text-gray-300 mb-6">Let's collaborate and bring your vision to life!</p>
          <motion.button
            onClick={() => scrollToSection('contact')}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-3 rounded-full font-semibold hover:shadow-xl transition-all relative overflow-hidden group"
          >
            <span className="relative z-10">Get Started Today</span>
            <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-700 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
          </motion.button>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;