import React from 'react';
import { Palette, Code, Smartphone, TrendingUp, Globe, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const Services = () => {
  const services = [
    {
      icon: Palette,
      title: 'Graphic Design',
      description: 'Creating stunning visual identities, logos, branding materials, and social media graphics that make your brand stand out.',
      features: ['Logo Design', 'Brand Identity', 'Social Media Graphics', 'Print Materials'],
      color: 'from-orange-400 to-orange-600'
    },
    {
      icon: Code,
      title: 'Web Development',
      description: 'Building responsive, SEO-friendly, and custom websites that deliver exceptional user experiences and drive conversions.',
      features: ['Custom Websites', 'E-commerce Solutions', 'CMS Development', 'Website Optimization'],
      color: 'from-orange-500 to-orange-700'
    },
    {
      icon: Smartphone,
      title: 'UI/UX Design',
      description: 'Designing user-centered interfaces that are both beautiful and functional, ensuring optimal user experiences across all devices.',
      features: ['User Research', 'Wireframing', 'Prototyping', 'Usability Testing'],
      color: 'from-orange-400 to-orange-500'
    },
    {
      icon: TrendingUp,
      title: 'Digital Marketing',
      description: 'Comprehensive digital marketing strategies to boost your online presence and drive measurable business growth.',
      features: ['SEO Optimization', 'Social Media Marketing', 'Content Strategy', 'Analytics'],
      color: 'from-orange-600 to-orange-800'
    },
    {
      icon: Globe,
      title: 'Brand Strategy',
      description: 'Developing comprehensive brand strategies that resonate with your target audience and create lasting connections.',
      features: ['Brand Positioning', 'Market Research', 'Brand Guidelines', 'Messaging Strategy'],
      color: 'from-orange-500 to-orange-600'
    },
    {
      icon: Zap,
      title: 'Creative Consulting',
      description: 'Expert creative consultation to help you make informed decisions and optimize your creative projects for maximum impact.',
      features: ['Project Planning', 'Creative Direction', 'Performance Analysis', 'Strategy Development'],
      color: 'from-orange-400 to-orange-700'
    }
  ];

  const fadeInUp = {
    initial: { opacity: 0, y: 60 },
    whileInView: { opacity: 1, y: 0 },
    transition: { duration: 0.6 },
    viewport: { once: true }
  };

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          {...fadeInUp}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-dark-800 mb-6">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive digital solutions designed to elevate your brand and drive business growth
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, rotateY: 5 }}
              className="group relative bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-2xl transition-all duration-300 transform-style-3d perspective-1000"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="relative z-10">
                <motion.div 
                  className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-6 shadow-lg`}
                  whileHover={{ scale: 1.1, rotateZ: 10 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <service.icon className="w-8 h-8 text-white" />
                </motion.div>

                <h3 className="text-2xl font-bold text-dark-800 mb-4 group-hover:text-orange-600 transition-colors">
                  {service.title}
                </h3>

                <p className="text-gray-600 mb-6 leading-relaxed">
                  {service.description}
                </p>

                <div className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <motion.div 
                      key={featureIndex} 
                      className="flex items-center text-sm text-gray-500"
                      whileHover={{ x: 5 }}
                    >
                      <div className="w-2 h-2 bg-orange-400 rounded-full mr-3"></div>
                      {feature}
                    </motion.div>
                  ))}
                </div>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg transition-all w-full relative overflow-hidden group"
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  <span className="relative z-10">Learn More</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-700 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          {...fadeInUp}
          className="mt-16 bg-gradient-to-r from-orange-50 to-orange-100 rounded-3xl p-12 text-center border border-orange-200 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-orange-600/5"></div>
          <div className="relative z-10">
            <h3 className="text-3xl font-bold text-dark-800 mb-6">
              Ready to Transform Your Digital Presence?
            </h3>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Let's collaborate to bring your vision to life with our expert team and proven process.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl transition-all relative overflow-hidden group"
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <span className="relative z-10">Start Your Project Today</span>
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-orange-700 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;